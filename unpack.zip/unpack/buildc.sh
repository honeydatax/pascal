# /bin/sh
gcc -o crcbyte crcbyte.c
gcc -o cript cript.c
gcc -o decript decript.c
gcc -o  pack pack.c
gcc -o unpack unpack.c
