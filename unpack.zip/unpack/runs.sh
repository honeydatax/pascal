# /bin/sh
rm pack.pck
rm pack.dat
echo crc:
./crcbyte $2
./decript $1 < $2 > pack.pck
./unpack pack.pck $3

