# /bin/sh
cd $2
rn buildc.sh
/usr/bin/unzip -u $1 
./buildc.sh