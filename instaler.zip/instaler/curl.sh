# /bin/sh
/usr/bin/curl $1 > $2
