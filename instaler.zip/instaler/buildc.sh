# /bin/sh
cd sample
gcc -o sample sample.c
rm *.c
echo to run write ./sample
rm *.sh