# /bin/sh
echo 0 > ins
./project1 ins &
for a in {0..10}
do
	printf "%s" $(expr $a "*" 10) > ins
	sleep 1
done