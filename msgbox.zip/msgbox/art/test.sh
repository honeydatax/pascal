# /bin/sh
echo starting > ins
./project1 ins &
	sleep 2
	printf "%s,%i,%i,%i,%i" rect 10 10 40 40  > ins
	sleep 2
	printf "%s,%i,%i,%i,%i" circle 50 50 100 100  > ins
	sleep 8
printf "end." > ins