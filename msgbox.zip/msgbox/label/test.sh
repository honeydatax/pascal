# /bin/sh
echo starting > ins
./project1 ins &
for a in *
do
	printf "%s %s" copyng $a > ins
	sleep 2
done

printf "end." > ins