# /bin/usr
./pass 100 8
