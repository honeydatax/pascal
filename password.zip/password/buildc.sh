# /bin/sh
gcc -o pass passgene.c
