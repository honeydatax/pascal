# /bin/sh
rm pack.pck
rm pack.dat
rm pack.crp
a=$(ls $2)
./pack $a pack.pck
./cript $1 < pack.pck > pack.crp
echo crc:
./crcbyte pack.crp